package spaceships;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.util.Random;

import main.MainClass;

public class SpaceShipENEMY extends SpaceShip{
	static Random Random = new Random();
	public static Image img;
	static {
		try {
			SpaceShipENEMY.img = ImageIO.read(MainClass.class.getResource("../images/Resources/images/ENEMY.png"));
			SpaceShipENEMY.img = SpaceShipENEMY.img.getScaledInstance(MainClass.spaceShipWidth,MainClass.spaceShipHeight,0);
		}
		catch (Exception ex) {System.out.println(ex);}
	}
	public SpaceShipENEMY(){
		SpaceShipName="ENEMY";
		horPace=40;
		verPace=40;
		xCoord=MainClass.cosmosWidth-MainClass.spaceShipWidth;
		yCoord=MainClass.yOffSet;
		super.SpaceShipImageIcon =new ImageIcon(SpaceShipENEMY.img);
	}

}
