package spaceships;

public class SpaceShipZERO extends SpaceShip{
	public static int verPace = 5;
	public static int horPace = 5;
	
	public SpaceShipZERO() {
		super(horPace,verPace);
	}
}
