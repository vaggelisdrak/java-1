package Enumerations;

public enum Bathmida {
	Lecturer,
	Assistant,
	Associate,
	Professor
}
