package spaceships;

public class SpaceShipALPHA extends SpaceShip{
	public static int verPace = 10;
	public static int horPace = 10;
	
	public SpaceShipALPHA() {
		super(horPace,verPace);
	}

}
