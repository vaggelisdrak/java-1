package gui;

import javax.swing.*;

import java.awt.*;
import spaceships.*;
import javax.swing.*;
import java.awt.*;

public class SelectSpaceShipScreen extends JPanel{
	private static final long serialVersionUID=1L;
	SelectSpaceShipScreen(){
		this.setLayout(new BorderLayout(0,0));
		this.add(createNorthPanel(),BorderLayout.NORTH);
		this.add(createCenterPanel(),BorderLayout.CENTER);
		this.add(createSouthPanel(),BorderLayout.SOUTH);
	}
	
	private JPanel createNorthPanel() {
		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(100,100));
		JLabel label = new JLabel("Please choose a spaceship");
		label.setFont(new Font("arcade classic",Font.PLAIN,25));
		label.setForeground(Color.WHITE);
		panel.setBackground(Color.BLACK);
		panel.add(label);
		return panel;
	}
	
	private JPanel createCenterPanel() {
		JButton btnspaceShipZero = new JButton();
		btnspaceShipZero.setBackground(Color.BLACK);
		JButton btnspaceShipAlpha = new JButton();
		btnspaceShipAlpha.setBackground(Color.BLACK);
		JButton btnspaceShipBeta = new JButton();
		btnspaceShipBeta.setBackground(Color.BLACK);
		JButton btnspaceShipGama = new JButton();
		btnspaceShipGama.setBackground(Color.BLACK);
		JButton btnspaceShipDelta = new JButton();
		btnspaceShipDelta.setBackground(Color.BLACK);
		
		btnspaceShipZero.addActionListener(new SpaceShipSelectionBtnHandler("SZERO"));
		btnspaceShipAlpha.addActionListener(new SpaceShipSelectionBtnHandler("SALPHA"));
		btnspaceShipBeta.addActionListener(new SpaceShipSelectionBtnHandler("SBETA"));
		btnspaceShipGama.addActionListener(new SpaceShipSelectionBtnHandler("SGAMA"));
		btnspaceShipDelta.addActionListener(new SpaceShipSelectionBtnHandler("SDELTA"));
		
		
		btnspaceShipZero.setIcon(new ImageIcon(SpaceShipZERO.img));
		btnspaceShipAlpha.setIcon(new ImageIcon(SpaceShipALPHA.img));
		btnspaceShipBeta.setIcon(new ImageIcon(SpaceShipBETA.img));
		btnspaceShipGama.setIcon(new ImageIcon(SpaceShipGAMA.img));
		btnspaceShipDelta.setIcon(new ImageIcon(SpaceShipDELTA.img));
		
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout());
		panel.setBackground(Color.BLACK);
		panel.add(btnspaceShipZero);
		panel.add(btnspaceShipAlpha);
		panel.add(btnspaceShipBeta);
		panel.add(btnspaceShipGama);
		panel.add(btnspaceShipDelta);
		return panel;
	}
	
	private JPanel createSouthPanel() {
		JPanel panel = new JPanel();
		panel.setBackground(Color.BLACK);
		return panel;
	}
	
}