package enumerations;

public enum StaffType {
    Permanent,
    HourlyBased
}
