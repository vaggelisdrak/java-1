package spaceships;

public interface Navigation {
	int moveUP();
	int moveDOWN();
	int moveLEFT();
	int moveRIGHT();
	
}
