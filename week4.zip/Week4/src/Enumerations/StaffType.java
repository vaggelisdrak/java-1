package Enumerations;


public enum StaffType {
    Permanent,
    HourlyBased
}
