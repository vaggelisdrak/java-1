package spaceships;
import javax.swing.ImageIcon;

import java.awt.Color;
import java.util.LinkedList;
import java.util.Random;

import main.MainClass;
import spaceships_laserguns.Laergun;
import spaceships_laserguns.Laser;

abstract public class SpaceShip implements Navigation{
	public LinkedList <Laser> laserShootersLinkedList = new LinkedList <Laser>();
	protected ImageIcon SpaceShipImageIcon;
	protected String SpaceShipName;
	protected int horPace;
	protected int verPace;	
	public int xCoord;
	public int yCoord;
	public Laergun gun = new Laergun(Color.WHITE);
	static Random Random = new Random();

	public ImageIcon getIcon() {
		return SpaceShipImageIcon;
	}
	
	public int getX() {
		return xCoord;
	}
	
	public int getY() {
		return yCoord;
	}
	
	public void fire(int x,int y) {
		laserShootersLinkedList.add(laserShootersLinkedList.size(),new Laser(x,y));
	}
	
	public int moveUP() {
		yCoord -= verPace;  
		if(yCoord<=MainClass.yOffSet)yCoord=MainClass.yOffSet;
		return yCoord;
	}
	
	public int moveDOWN() {
		int limit=MainClass.cosmosHeight-MainClass.spaceShipHeight-MainClass.yOffSet;
		yCoord += verPace; 
		if(yCoord>=limit)yCoord=limit;
		return yCoord;
	}
	
	public int moveLEFT() {
		xCoord -= horPace;    
 	    if(xCoord<0)xCoord = xCoord+horPace;
		return xCoord;
	}

	public int moveRIGHT() {
		int limit=(MainClass.cosmosWidth-MainClass.spaceShipWidth);   
		xCoord += horPace;
		if(xCoord>=limit)xCoord=limit;
 		return xCoord;
	}
	
	public void printCoords() {
		 System.out.println("Spaceship"+SpaceShipName+" "+ "Xcoords:"+xCoord+" Ycoords:"+yCoord);
	}

	public void huntUserSpaceShip(SpaceShip userSpaceShip) {
		int mv = Random.nextInt(10);
		if(mv==0) {
			this.gun.fire(this.getX(),this.getY()+100);
		}
		if(userSpaceShip.xCoord > this.xCoord) {
			this.xCoord=this.moveRIGHT();
		}
		else{
			this.xCoord=this.moveLEFT();
		}
		
		int res;
		res = Random.nextInt(20);
		if(res==5 || res ==10)this.moveLEFT();
		else this.moveRIGHT();

	}
}
