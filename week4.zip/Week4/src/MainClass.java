import Enumerations.StaffType;
import Randomize.Randomize;

public class MainClass {
	public static void main(String[] args) {
		System.out.println("HELLO PROJECT WEEK 4");
		createRandomizedEmployees(100);
	}
	public static void createRandomizedEmployees(int k) {
		int HourlyBasedStaffmonthlysalary=0;
		int PermanentStaffmonthlysalary=0;
		int HourlyBasedStaff=0;
		int PermanentStaff =0;
		System.out.println("creating"+ k +"randomized employees");
		int i;
		for(i=1;i<=k;i++) {
			StaffType staff = Randomize.Staff();
			if (staff==StaffType.Permanent) {
				PermanentStaff++;
				PermanentStaff pstaff = new PermanentStaff(i);
				pstaff.CalculateMonthlySalary();
				pstaff.printInfo();
				PermanentStaffmonthlysalary += pstaff.CalculateMonthlySalary();
			}
			if (staff==StaffType.HourlyBased) {
				HourlyBasedStaff++;
				HourlyBasedStaff hstaff = new HourlyBasedStaff(i);
				hstaff.CalculateMonthlySalary();
				hstaff.printInfo();
				HourlyBasedStaffmonthlysalary += hstaff.CalculateMonthlySalary();
			}
		}
		System.out.println("The monthly cost of "+HourlyBasedStaff+" hourly based staff is "+HourlyBasedStaffmonthlysalary);
		System.out.println("The monthly cost of "+PermanentStaff+" permanent staff is "+PermanentStaffmonthlysalary);
		int totalcost = PermanentStaffmonthlysalary + HourlyBasedStaffmonthlysalary;
		System.out.println("The monthly cost of the univeristy's academic staff is "+totalcost);
	}
	
}
