
import Enumerations.WorkingExperience;
import Randomize.Randomize;


final public class HourlyBasedStaff extends Academic{
	private WorkingExperience experience;
	private int workedhours;
	private int monthlysalary;
	
	public HourlyBasedStaff(int id) {
		super(id);
		experience = Randomize.WorkingExperience();
		workedhours = Randomize.MonthlyWorkingHours();
	}
	
	@Override
	public int CalculateMonthlySalary() {
		int onTopSalary = 0;
		if (experience==WorkingExperience.uptoFiveYears) {
			onTopSalary = 10*workedhours;
		}
		if (experience==WorkingExperience.FiveToTenYears) {
			onTopSalary = 20*workedhours;
		}
		if (experience==WorkingExperience.morethanTenYears) {
			onTopSalary = 30*workedhours;
		}
		monthlysalary = baseMonthlySalary + onTopSalary;
		return monthlysalary;
	}
	public WorkingExperience getWorkingExperience() {
		return experience;
	}
	
	public int getWorkedHours() {
		return workedhours;
	}
	public void printInfo() {
		System.out.println("");
		System.out.println("EmployeeID:"+super.getEmployeeID()+"is an hourly based employee");
		System.out.println("Academic experience:"+ experience);
		System.out.println("Monthly salary:"+monthlysalary);
	}
}
