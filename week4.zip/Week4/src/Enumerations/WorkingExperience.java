package Enumerations;

public enum WorkingExperience {
	uptoFiveYears,
	FiveToTenYears,
	morethanTenYears
}
