package spaceships;


public abstract class SpaceShip implements Navigation{
	public int shipWidth;
	public int shipHeight;
	public int xCoord;
	public int yCoord;
	public int horPace;
	public int verPace;
	
	SpaceShip(int horPace,int verPace){
		this.horPace = horPace;
		this.verPace = verPace;
	}
	
	public int moveLEFT() {
		xCoord -= horPace;
		if(xCoord<0) {
			xCoord = xCoord + horPace;
		}
		return xCoord;
	}
	
	public int moveRIGHT() {
		xCoord += horPace;
		if(xCoord>700) { /*cosmosWidth*/
			xCoord = xCoord - horPace;
		}
		return xCoord;
	}
	
	public int moveUP() {
		yCoord += verPace;
		if(yCoord<0) {
			yCoord = yCoord - verPace;
		}
		return yCoord;
	}
	
	public int moveDOWN() {
		yCoord -= verPace;
		if(yCoord>700) { /*cosmosHeight*/
			yCoord = yCoord + verPace;
		}
		return yCoord;
	}

	public void printCoords(SpaceShip spaceShip) {
		System.out.println(spaceShip+" xCoords: "+xCoord+" yCoords: "+yCoord);
		
	}

	
}
