package spaceships;

public class SpaceShipBETA extends SpaceShip{
	public static int verPace = 20;
	public static int horPace = 20;
	
	public SpaceShipBETA() {
		super(horPace,verPace);
	}
}
