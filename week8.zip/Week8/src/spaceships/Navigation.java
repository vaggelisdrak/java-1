package spaceships;

public interface Navigation {
	int moveUP();//return ycoord
	int moveDOWN();//return ycoord
	int moveLEFT();//return xcoord
	int moveRIGHT();//return xcoord
}
