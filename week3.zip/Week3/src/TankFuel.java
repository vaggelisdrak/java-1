
public class TankFuel {
	final double gasolineTankCapacity;
	double tankFuel = 0;
	
	public TankFuel(double gasolineTankCapacity) {
		this.gasolineTankCapacity = gasolineTankCapacity;
	}
	
	public double getTankFuel() {
		return Math.round(tankFuel * 100.0) / 100.0;
	}
	
	public double getTankCapacity() {
		return gasolineTankCapacity;
	}
	
	public void fuelTank(double fuelTempo)throws TankFullException,InvalidFuelTempoException{
		if((fuelTempo !=0.1) && (fuelTempo !=0.2)) {
			throw new InvalidFuelTempoException("Sorry, fuel tempo is not supported");	
		}
		
		if(gasolineTankCapacity == (Math.round(tankFuel * 100.0) / 100.0)) {
			throw new TankFullException("Tank is full!");	
		}
		else {
			tankFuel += fuelTempo;
		}
	}

}
