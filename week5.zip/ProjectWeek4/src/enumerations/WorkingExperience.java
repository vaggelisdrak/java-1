package enumerations;

public enum WorkingExperience {
uptoFiveYears,
FiveToTenYears,
morethanTenYears
}
