
public class TankFullException extends Exception{
		public TankFullException(String str) {
			super(str);
		}
}