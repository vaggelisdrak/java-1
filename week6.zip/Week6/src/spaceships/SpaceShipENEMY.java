package spaceships;

public class SpaceShipENEMY extends SpaceShip{
	public static int verPace = 15;
	public static int horPace = 15;
	
	public SpaceShipENEMY() {
		super(horPace,verPace);
	}
}
