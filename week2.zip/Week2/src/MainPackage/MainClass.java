package MainPackage;

import basicElements.Point;
import twoDimensionalShape.Circle;
import twoDimensionalShape.Rectangle;
import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		
		/*
		 Συμπληρώστε τον κώδικα σχετικά 
		 με τον διάλογο του χρήστη με το πρόγραμμά σας
		*/
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Δώσε το χ0 του κάτω αριστερά άκρου");
		int x0 = scan.nextInt();
		
		System.out.println("Δώσε το y0 του κάτω αριστερά άκρου");
		int y0 = scan.nextInt();
		
		Point p=new Point(x0,y0);
		
		System.out.println("Πληκτρολόγησε 0 αν θες να δημιουργήσεις κύκλο, 1 αν θες ορθογώνιο");
		int choice = scan.nextInt();
		
		if(choice == 0) {
			System.out.println("Δώσε την ακτίνα του κύκλου");
			double r = scan.nextDouble();
			
			Circle objCircle=new Circle(p,r);
			System.out.println("Area of Circle:"+objCircle.getArea());
		}
		else if(choice == 1) {
			System.out.println("Δώσε το πλάτος του ορθογωνίου");
			double w = scan.nextDouble();
			
			System.out.println("Δώσε το μήκος του ορθογωνίου");
			double h = scan.nextDouble();
			
			Rectangle objRect=new Rectangle(p,w,h);
			System.out.println("Area of Rectangle:"+objRect.getArea());
		}
		else {
			System.out.println("Δεν υπάρχει αυτή η επιλογή");

		}
	}
}
