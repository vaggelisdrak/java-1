package spaceships;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import main.MainClass;

public class SpaceShipENEMY extends SpaceShip{
	public static Image img;
	static {
		try {
			SpaceShipENEMY.img = ImageIO.read(MainClass.class.getResource("../images/Resources/images/ENEMY.png"));
		}
		catch (Exception ex) {System.out.println(ex);}
	}
	public SpaceShipENEMY(){
		SpaceShipName="ENEMY";
		horPace=40;
		verPace=40;
		xCoord=MainClass.cosmosWidth-MainClass.spaceShipWidth;
		yCoord=MainClass.yOffSet;
		super.SpaceShipImageIcon =new ImageIcon(SpaceShipENEMY.img);
	}
	

}
