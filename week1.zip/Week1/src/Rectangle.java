public class Rectangle {
	private float x=0;
	private float y=0;
	private float width,height=0;
	private static int numberOfObj;
	
	Rectangle(float px,float py,float w,float h){ /*constructor*/
		x=px;
		y=py;
		width=w;
		height=h;
		numberOfObj++;
	}
	
	public boolean contains(float sx,float sy) {
		boolean res=false;
		
		if(0 <= sx  && sx <= width) {
			if(0 <= sy  && sy <= height) {
				res = true;
			}
		}
		return res;
	}
}
