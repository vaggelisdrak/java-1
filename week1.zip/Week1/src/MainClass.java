import java.util.Scanner;

public class MainClass {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Δώσε το χ0 του κάτω αριστερά άκρου του ορθογωνίου");
		float x0 = scan.nextFloat();
		System.out.println("Δώσε το y0 του κάτω αριστερά άκρου του ορθογωνίου");
		float y0 = scan.nextFloat();
		System.out.println("Δώσε το ύψος του ορθογωνίου");
		float h = scan.nextFloat();
		System.out.println("Δώσε το μήκος του ορθογωνίου");
		float w = scan.nextFloat();
		
		Rectangle objRect = new Rectangle(x0,y0,h,w);
		
		System.out.println("Δώσε το x ενός σημείου");
		float x = scan.nextFloat();
		System.out.println("Δώσε το y ενός σημείου");
		float y = scan.nextFloat();
		
		if(objRect.contains(x, y) == true ) {
			System.out.println("Το σημείο που έδωσες ανήκει στο ορθογώνιο --- ΙΝ");
		}
		else {
			System.out.println("Το σημείο που έδωσες δεν ανήκει στο ορθογώνιο --- OUT");
		}
	}
	

}
