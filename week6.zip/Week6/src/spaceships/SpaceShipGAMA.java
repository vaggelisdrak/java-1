package spaceships;

public class SpaceShipGAMA extends SpaceShip{
	public static int verPace = 30;
	public static int horPace = 30;
	
	public SpaceShipGAMA() {
		super(horPace,verPace);
	}
}
