package gui;
import java.awt.event.KeyEvent;

import java.awt.event.KeyListener;
import java.util.TimerTask;

import javax.swing.*;

import main.MainClass;
import spaceships.SpaceShip;
import spaceships.SpaceShipENEMY;

import java.awt.*;
import java.util.TimerTask;
import java.util.Timer;

public class GamePlayScreen extends JPanel implements KeyListener{
	private static final long serialVersionUID = 1L;
	static int i=0;
	static int score=0;
	static JLabel l;
	 
	
	private SpaceShip userSpaceShip;
	private SpaceShip enemySpaceShip;
	GamePlayScreen(){
		addKeyListener(this);
		this.setVisible(true);
		this.setBackground(Color.BLACK);
		l = new JLabel();
		l.setForeground(Color.WHITE);
		boardChanged(score);
		this.add(l);
		createDaemon();
	}

	private void createDaemon() {
		Timer timer = new Timer();
		TimerTask task = new monitorDaemonGame();
		timer.schedule(task, 100, 100);
	}
	
class monitorDaemonGame extends TimerTask{
	public void run() {
		repaint();
		}
	}
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		enemySpaceShip.huntUserSpaceShip(userSpaceShip);
		userSpaceShip.getIcon().paintIcon(this,g,userSpaceShip.getX(),userSpaceShip.getY());
		enemySpaceShip.getIcon().paintIcon(this,g,enemySpaceShip.getX(),enemySpaceShip.getY());
		showLaserShootings(g);
	}
	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_UP) userSpaceShip.moveUP();
		if(e.getKeyCode() == KeyEvent.VK_DOWN) userSpaceShip.moveDOWN();
		if(e.getKeyCode() == KeyEvent.VK_LEFT) userSpaceShip.moveLEFT();
		if(e.getKeyCode() == KeyEvent.VK_RIGHT) userSpaceShip.moveRIGHT();
		if(e.getKeyCode() == KeyEvent.VK_SPACE) userSpaceShip.gun.fire(userSpaceShip.getX(),userSpaceShip.getY());
		if(e.getKeyCode() == KeyEvent.VK_B) SpaceFrame.cardLayout.next(SpaceFrame.spaceFramePanel);
		this.repaint();
	}
	@Override
	public void keyReleased (KeyEvent e) {}
	
	@Override
	public void keyTyped (KeyEvent e) {}
	public void setUserSpaceShip(SpaceShip use1) {
		userSpaceShip = use1;
		enemySpaceShip = new SpaceShipENEMY();
	}
	
	public void boardChanged(int score) {
        l.setText("Score: " + score);
    }
	
	
	public void showLaserShootings(Graphics g) {
		userSpaceShip.gun.laserShootersLinkedList.forEach((tmp)->{
			g.setColor(userSpaceShip.gun.lasercolor);
			g.drawLine(tmp.x,tmp.y,tmp.x,tmp.y-15);
			tmp.y = tmp.y-15;
			double distance = Math.sqrt((Math.pow(tmp.x - (enemySpaceShip.xCoord+(MainClass.spaceShipWidth/2)), 2)) + (Math.pow(tmp.y - (enemySpaceShip.yCoord+MainClass.spaceShipHeight), 2)));
			if(distance<25) {
				System.out.println("score is: "+score);
				boardChanged(score);
				score++;
			}
		});
		enemySpaceShip.gun.laserShootersLinkedList.forEach((tmp)->{
			g.setColor(enemySpaceShip.gun.lasercolor);
			g.drawLine(tmp.x,tmp.y,tmp.x,tmp.y+15);
			tmp.y = tmp.y +15;
			double distance = Math.sqrt((Math.pow(tmp.x - (userSpaceShip.xCoord+(MainClass.spaceShipWidth/2)), 2)) + (Math.pow(tmp.y - (userSpaceShip.yCoord+MainClass.spaceShipHeight), 2)));
			if(distance<25) {
				System.out.println(i);
				i+=1;
			}
			if(i==20) {
				i=0;
				System.out.println("Game Over!");
				SpaceFrame restart = new SpaceFrame(MainClass.cosmosWidth,MainClass.cosmosHeight);
			}
		});
	}
}
