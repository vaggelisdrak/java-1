package spaceships;

public class SpaceShipDELTA extends SpaceShip{
	public static int verPace = 40;
	public static int horPace = 40;
	
	public SpaceShipDELTA() {
		super(horPace,verPace);
	}
}
