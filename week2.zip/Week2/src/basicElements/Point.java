package basicElements;

public class Point {
	int xcoords;
	int ycoords;
	public Point(int x, int y){ 
		xcoords=x;
		ycoords=y;
		
	}

}
