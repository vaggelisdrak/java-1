package spaceships;

import javax.swing.ImageIcon;
import javax.imageio.ImageIO;
import java.awt.*;
import main.MainClass;

public class SpaceShipGAMA extends SpaceShip{
	public static Image img;
	static {
		try {
			SpaceShipGAMA.img = ImageIO.read(MainClass.class.getResource("../images/Resources/images/GAMA.png"));
		}
		catch (Exception ex) {System.out.println(ex);}
	}
	
	public SpaceShipGAMA(){
		SpaceShipName="GAMA";
		horPace=30;
		verPace=30;
		xCoord=0;
		yCoord=MainClass.cosmosHeight-MainClass.spaceShipHeight-MainClass.yOffSet;
		super.SpaceShipImageIcon =new ImageIcon(SpaceShipGAMA.img);
	}

	
}
