
public class MainClass {
	public static void main(String[] args) {
		System.out.println("hello java");
		TankFuel myTank = new TankFuel(50.0);
		boolean fillTank = true;
		double fuelTempo = 0.1;
		int i =0;
		while(fillTank) {
			System.out.println(myTank.getTankFuel());
			try {
				myTank.fuelTank(fuelTempo);
			}
			catch(TankFullException ex) {
				fillTank = false;
				System.out.println(ex.getMessage());
			}
			catch (InvalidFuelTempoException ex) {
				fillTank = false;
				System.out.println(ex.getMessage());
			}
		}
		System.out.println(myTank.getTankFuel());
		myTank = null;

	}
}

